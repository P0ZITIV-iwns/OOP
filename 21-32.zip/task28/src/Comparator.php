<?php

namespace App\Comparator;

use Ds\Stack;

function compare($seq1, $seq2)
{
    return getActualString(new Stack(), $seq1) === getActualString(new Stack(), $seq2);
}

function getActualString(Stack $stack, $sequence)
{
    for ($i = 0; $i < strlen($sequence); $i++) {
        if ($sequence[$i] === '#') {
            $stack->push($sequence[$i]);
        } else {
            if (!$stack->isEmpty()) {
                $stack->pop();
            }
        }
    }

    return $stack->join('');
}