<?php
namespace App;
class User
{
    public $id;
}