<?php
namespace App;
class Cat
{
    public $id;
}