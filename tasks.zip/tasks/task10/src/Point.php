<?php

namespace App;

class Point
{
    public $x;
    public $y;
}