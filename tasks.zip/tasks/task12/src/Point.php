<?php
namespace App;

class Point
{
    public $x;
    public $y;
    public function __construct(float $x, float $y)
    {
        $this->x = $x;
        $this->y = $y;
    }
}