<?php

namespace App;

class Guest
{
    public function getName()
    {
        return 'Guest';
    }
}
